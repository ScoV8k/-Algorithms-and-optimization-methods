Kod projektu GPS. Wymaga Pythona, NumPy i SciPy. Skrypty należy uruchamiać z tego katalogu. dane_35.csv zawiera dane wejściowe.
